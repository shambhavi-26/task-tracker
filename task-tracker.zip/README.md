# 📝 Daily Task Tracker (CLI)

A simple command-line daily task tracker using Python and `rich`.

## 📌 Features

- Add daily tasks
- View today's or all tasks
- Mark tasks as done
- Delete tasks
- Pretty CLI output

## 🚀 Usage

```bash
# Install dependencies
pip install -r requirements.txt

# Add a task
python task_tracker.py add "Read a book"

# List today’s tasks
python task_tracker.py list

# List all tasks
python task_tracker.py all

# Mark task as done
python task_tracker.py done 1

# Delete a task
python task_tracker.py delete 2
```
