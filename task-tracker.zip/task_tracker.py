import json
import argparse
import os
from datetime import date
from rich.console import Console
from rich.table import Table

DATA_FILE = "tasks.json"
console = Console()


class TaskManager:
    def __init__(self, filename):
        self.filename = filename
        self.tasks = self.load_tasks()

    def load_tasks(self):
        if not os.path.exists(self.filename):
            return {}
        with open(self.filename, "r") as f:
            return json.load(f)

    def save_tasks(self):
        with open(self.filename, "w") as f:
            json.dump(self.tasks, f, indent=4)

    def add_task(self, task):
        today = str(date.today())
        if today not in self.tasks:
            self.tasks[today] = []
        self.tasks[today].append({"task": task, "done": False})
        self.save_tasks()
        console.print(f"[green]Task added:[/] {task}")

    def list_tasks(self, show_all=False):
        if show_all:
            for d, tasks in self.tasks.items():
                console.print(f"\n[bold blue]{d}[/bold blue]")
                self._print_task_table(tasks)
        else:
            today = str(date.today())
            tasks = self.tasks.get(today, [])
            console.print(f"\n[bold blue]{today}[/bold blue]")
            self._print_task_table(tasks)

    def _print_task_table(self, tasks):
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("ID", justify="right")
        table.add_column("Task")
        table.add_column("Status")
        for i, task in enumerate(tasks, 1):
            status = "[green]Done[/]" if task["done"] else "[red]Pending[/]"
            table.add_row(str(i), task["task"], status)
        console.print(table)

    def complete_task(self, task_id):
        today = str(date.today())
        try:
            self.tasks[today][task_id - 1]["done"] = True
            self.save_tasks()
            console.print(f"[green]Marked task #{task_id} as complete[/green]")
        except (IndexError, KeyError):
            console.print("[red]Invalid task ID[/red]")

    def delete_task(self, task_id):
        today = str(date.today())
        try:
            task = self.tasks[today].pop(task_id - 1)
            self.save_tasks()
            console.print(f"[yellow]Deleted task:[/] {task['task']}")
        except (IndexError, KeyError):
            console.print("[red]Invalid task ID[/red]")


def main():
    parser = argparse.ArgumentParser(description="Daily Task Tracker")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("list", help="List today's tasks")
    subparsers.add_parser("all", help="List all tasks")

    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("task", help="Task description")

    complete_parser = subparsers.add_parser("done", help="Mark a task as done")
    complete_parser.add_argument("id", type=int, help="Task ID")

    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    args = parser.parse_args()
    manager = TaskManager(DATA_FILE)

    if args.command == "add":
        manager.add_task(args.task)
    elif args.command == "list":
        manager.list_tasks()
    elif args.command == "all":
        manager.list_tasks(show_all=True)
    elif args.command == "done":
        manager.complete_task(args.id)
    elif args.command == "delete":
        manager.delete_task(args.id)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
